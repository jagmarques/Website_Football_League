-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 30-Nov-2019 às 20:55
-- Versão do servidor: 10.4.8-MariaDB
-- versão do PHP: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `db_project`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `application`
--

CREATE TABLE `application` (
  `app_name` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `application`
--

INSERT INTO `application` (`app_name`) VALUES
('db_project');

-- --------------------------------------------------------

--
-- Estrutura da tabela `contest`
--

CREATE TABLE `contest` (
  `contest_name` varchar(512) NOT NULL,
  `contest_date_start` date DEFAULT NULL,
  `contest_date_end` date DEFAULT NULL,
  `player_user_name` varchar(512) NOT NULL,
  `application_app_name` varchar(512) NOT NULL,
  `number_teams` int(11) DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `state` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `contest`
--

INSERT INTO `contest` (`contest_name`, `contest_date_start`, `contest_date_end`, `player_user_name`, `application_app_name`, `number_teams`, `location`, `state`) VALUES
('', '2019-12-02', '2019-11-06', 'monteiro', 'db_project', 0, 'aqui', 0),
('222222', NULL, NULL, 'monteiro', 'db_project', 0, '', 0),
('asd', '2019-12-17', '2019-12-31', 'monteiro', 'db_project', 0, 'fora', 0),
('torneio1', NULL, NULL, 'monteiro', 'db_project', 0, 'Aquibaseotango', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `contest_field`
--

CREATE TABLE `contest_field` (
  `contest_contest_name` varchar(512) NOT NULL,
  `field_field_name` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `contest_result`
--

CREATE TABLE `contest_result` (
  `rank` int(11) NOT NULL,
  `contest_contest_name` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `field`
--

CREATE TABLE `field` (
  `field_name` varchar(512) NOT NULL,
  `price_per_hour` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `game`
--

CREATE TABLE `game` (
  `price` float NOT NULL,
  `game_date` date DEFAULT NULL,
  `game_hour` int(11) NOT NULL,
  `state` tinyint(4) DEFAULT NULL,
  `goals_a` int(11) DEFAULT NULL,
  `goals_b` int(11) DEFAULT NULL,
  `team_team_name` varchar(512) NOT NULL,
  `field_field_name` varchar(512) NOT NULL,
  `team_team_name1` varchar(512) NOT NULL,
  `contest_contest_name` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `game`
--

INSERT INTO `game` (`price`, `game_date`, `game_hour`, `state`, `goals_a`, `goals_b`, `team_team_name`, `field_field_name`, `team_team_name1`, `contest_contest_name`) VALUES
(2, '2019-11-30', 19, 0, NULL, NULL, 'inkas', '', 'ras', 'torneio1');

-- --------------------------------------------------------

--
-- Estrutura da tabela `player`
--

CREATE TABLE `player` (
  `first_name` varchar(512) NOT NULL,
  `last_name` varchar(512) NOT NULL,
  `user_name` varchar(512) NOT NULL,
  `password` varchar(512) NOT NULL,
  `e_mail` varchar(512) NOT NULL,
  `phone_number` bigint(20) DEFAULT NULL,
  `can_open_contest` tinyint(1) NOT NULL,
  `admin` tinyint(1) NOT NULL,
  `cc` int(11) NOT NULL,
  `application_app_name` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `player`
--

INSERT INTO `player` (`first_name`, `last_name`, `user_name`, `password`, `e_mail`, `phone_number`, `can_open_contest`, `admin`, `cc`, `application_app_name`) VALUES
('admin', 'admin', 'admin', 'admin', 'admin@admin', NULL, 1, 1, 1234578, 'db_project'),
('João', 'Monteiro', 'monteiro', '123', 'jmmonteiro1998@gmail.com', NULL, 0, 0, 1325235, 'db_project');

-- --------------------------------------------------------

--
-- Estrutura da tabela `player_contest`
--

CREATE TABLE `player_contest` (
  `player_user_name` varchar(512) NOT NULL,
  `contest_contest_name` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `player_team`
--

CREATE TABLE `player_team` (
  `player_user_name` varchar(512) NOT NULL,
  `team_team_name` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `player_team`
--

INSERT INTO `player_team` (`player_user_name`, `team_team_name`) VALUES
('admin', 'ola'),
('admin', 'team1'),
('admin', 'team2'),
('monteiro', 'team1'),
('monteiro', 'team2');

-- --------------------------------------------------------

--
-- Estrutura da tabela `quantity`
--

CREATE TABLE `quantity` (
  `quantity` float NOT NULL,
  `contest_contest_name` varchar(512) NOT NULL,
  `player_user_name` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `team`
--

CREATE TABLE `team` (
  `team_name` varchar(512) NOT NULL,
  `can_play` tinyint(1) NOT NULL,
  `player_user_name` varchar(512) NOT NULL,
  `contest_contest_name` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `team`
--

INSERT INTO `team` (`team_name`, `can_play`, `player_user_name`, `contest_contest_name`) VALUES
('ola', 0, 'admin', 'torneio1'),
('team1', 0, 'monteiro', 'torneio1'),
('team2', 0, 'monteiro', 'asd');

-- --------------------------------------------------------

--
-- Estrutura da tabela `team_contest_result`
--

CREATE TABLE `team_contest_result` (
  `team_team_name` varchar(512) NOT NULL,
  `contest_result_rank` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`app_name`);

--
-- Índices para tabela `contest`
--
ALTER TABLE `contest`
  ADD PRIMARY KEY (`contest_name`),
  ADD KEY `contest_fk1` (`player_user_name`),
  ADD KEY `contest_fk2` (`application_app_name`);

--
-- Índices para tabela `contest_field`
--
ALTER TABLE `contest_field`
  ADD PRIMARY KEY (`contest_contest_name`,`field_field_name`),
  ADD KEY `contest_field_fk2` (`field_field_name`);

--
-- Índices para tabela `contest_result`
--
ALTER TABLE `contest_result`
  ADD PRIMARY KEY (`rank`),
  ADD KEY `contest_result_fk1` (`contest_contest_name`);

--
-- Índices para tabela `field`
--
ALTER TABLE `field`
  ADD PRIMARY KEY (`field_name`);

--
-- Índices para tabela `game`
--
ALTER TABLE `game`
  ADD KEY `game_fk1` (`team_team_name`),
  ADD KEY `game_fk2` (`field_field_name`),
  ADD KEY `game_fk3` (`team_team_name1`),
  ADD KEY `game_fk4` (`contest_contest_name`);

--
-- Índices para tabela `player`
--
ALTER TABLE `player`
  ADD PRIMARY KEY (`user_name`),
  ADD UNIQUE KEY `cc` (`cc`),
  ADD KEY `player_fk1` (`application_app_name`);

--
-- Índices para tabela `player_contest`
--
ALTER TABLE `player_contest`
  ADD PRIMARY KEY (`player_user_name`,`contest_contest_name`),
  ADD KEY `player_contest_fk2` (`contest_contest_name`);

--
-- Índices para tabela `player_team`
--
ALTER TABLE `player_team`
  ADD PRIMARY KEY (`player_user_name`,`team_team_name`);

--
-- Índices para tabela `quantity`
--
ALTER TABLE `quantity`
  ADD PRIMARY KEY (`quantity`,`contest_contest_name`,`player_user_name`),
  ADD KEY `quantity_fk1` (`contest_contest_name`),
  ADD KEY `quantity_fk2` (`player_user_name`);

--
-- Índices para tabela `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`team_name`),
  ADD KEY `team_fk1` (`player_user_name`);

--
-- Índices para tabela `team_contest_result`
--
ALTER TABLE `team_contest_result`
  ADD PRIMARY KEY (`team_team_name`),
  ADD KEY `team_contest_result_fk2` (`contest_result_rank`);

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `contest`
--
ALTER TABLE `contest`
  ADD CONSTRAINT `contest_fk1` FOREIGN KEY (`player_user_name`) REFERENCES `player` (`user_name`),
  ADD CONSTRAINT `contest_fk2` FOREIGN KEY (`application_app_name`) REFERENCES `application` (`app_name`);

--
-- Limitadores para a tabela `contest_field`
--
ALTER TABLE `contest_field`
  ADD CONSTRAINT `contest_field_fk1` FOREIGN KEY (`contest_contest_name`) REFERENCES `contest` (`contest_name`),
  ADD CONSTRAINT `contest_field_fk2` FOREIGN KEY (`field_field_name`) REFERENCES `field` (`field_name`);

--
-- Limitadores para a tabela `contest_result`
--
ALTER TABLE `contest_result`
  ADD CONSTRAINT `contest_result_fk1` FOREIGN KEY (`contest_contest_name`) REFERENCES `contest` (`contest_name`);

--
-- Limitadores para a tabela `player`
--
ALTER TABLE `player`
  ADD CONSTRAINT `player_fk1` FOREIGN KEY (`application_app_name`) REFERENCES `application` (`app_name`);

--
-- Limitadores para a tabela `player_contest`
--
ALTER TABLE `player_contest`
  ADD CONSTRAINT `player_contest_fk1` FOREIGN KEY (`player_user_name`) REFERENCES `player` (`user_name`),
  ADD CONSTRAINT `player_contest_fk2` FOREIGN KEY (`contest_contest_name`) REFERENCES `contest` (`contest_name`);

--
-- Limitadores para a tabela `quantity`
--
ALTER TABLE `quantity`
  ADD CONSTRAINT `quantity_fk1` FOREIGN KEY (`contest_contest_name`) REFERENCES `contest` (`contest_name`),
  ADD CONSTRAINT `quantity_fk2` FOREIGN KEY (`player_user_name`) REFERENCES `player` (`user_name`);

--
-- Limitadores para a tabela `team`
--
ALTER TABLE `team`
  ADD CONSTRAINT `team_fk1` FOREIGN KEY (`player_user_name`) REFERENCES `player` (`user_name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `team_contest_result`
--
ALTER TABLE `team_contest_result`
  ADD CONSTRAINT `team_contest_result_fk1` FOREIGN KEY (`team_team_name`) REFERENCES `team` (`team_name`),
  ADD CONSTRAINT `team_contest_result_fk2` FOREIGN KEY (`contest_result_rank`) REFERENCES `contest_result` (`rank`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
